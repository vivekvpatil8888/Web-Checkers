package com.webcheckers.model;

/**
 * The Class Modal.
 *
 * @author <a href='mailto:epw9195@rit.edu'>Ed Werner</a>
 */
public class Modal {

    public Modal() {
    	
    }
}
