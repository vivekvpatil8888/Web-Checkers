package com.webcheckers.model;

/**
 * The Class Score.
 *
 * @author <a href='mailto:epw9195@rit.edu'>Ed Werner</a>
 */
public class Score {

    public Score() {
    	
    }
}