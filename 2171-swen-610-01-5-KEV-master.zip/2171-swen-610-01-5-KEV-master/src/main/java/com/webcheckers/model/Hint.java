package com.webcheckers.model;

/**
 * The Class Hint.
 *
 * @author <a href='mailto:epw9195@rit.edu'>Ed Werner</a>
 */
public class Hint {

}
