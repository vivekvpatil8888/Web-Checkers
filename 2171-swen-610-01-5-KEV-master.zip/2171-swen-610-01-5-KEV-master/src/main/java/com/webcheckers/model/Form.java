package com.webcheckers.model;

/**
 * The Class Form.
 *
 * @author <a href='mailto:epw9195@rit.edu'>Ed Werner</a>
 */
public class Form {
    public Form() {
    	
    }
}
