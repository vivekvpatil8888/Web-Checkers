# Web Checkers Home

Welcome to the Web Checkers Project!

## Team

* Kishan K C

* Ebtesam Alsogaih

* Vivek Patil

* Edward Werner

## [Design Documentation](DesignDoc)

Click above for details of the Web Checkers design documentation.

## [Setup Guide](SetupGuide)

Click above for details about how to setup your development environment to work on this project.
